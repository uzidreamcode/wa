/**
 * Premium code / feature
 * Kamu bisa melakukan donasi terlebih dahulu untuk mendapatkan seluruh kode
 * lakukan donasi melalui link ini https://bit.ly/34IDvrD
 */
