module.exports = {
  prefix: "!",
  owner: "YOUR NUMBER",
  support: "YOUR GROUP ID",
};
